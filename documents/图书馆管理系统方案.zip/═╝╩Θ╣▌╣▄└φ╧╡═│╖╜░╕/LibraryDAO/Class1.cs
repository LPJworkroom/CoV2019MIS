﻿using System;

namespace LibraryDAO
{
    public class Class1
    {
    }
}
