﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using Newtonsoft.Json.Linq;
using System.Net;
using System.IO;
using Sunisoft.IrisSkin;


namespace 图书馆管理系统
{
    public partial class Form1 : Form
    {
        private SkinEngine skinEngine1;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //此皮肤控件，对话框标题栏文字不能长
            skinEngine1 = new SkinEngine();
            skinEngine1.SkinFile = "MSN.ssk";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //网络请求数据
            WebRequest wReq = WebRequest.Create("https://lab.isaaclin.cn/nCoV/api/overall");
            WebResponse wResp = wReq.GetResponse();
            Stream respStream = wResp.GetResponseStream();
            StreamReader reader = new StreamReader(respStream, Encoding.GetEncoding("UTF-8"));
            //json解析
            string json = reader.ReadToEnd();
            JObject jObject = JObject.Parse(json);
            MessageBox.Show(jObject["success"].ToString());
            MessageBox.Show(jObject["results"][0]["currentConfirmedCount"].ToString());
        }
    }
}
