﻿using System;

namespace LibraryModel
{
    public class Class1
    {
    }
}
