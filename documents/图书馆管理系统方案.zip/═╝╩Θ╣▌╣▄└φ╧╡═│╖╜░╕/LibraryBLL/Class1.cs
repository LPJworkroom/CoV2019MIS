﻿using System;

namespace LibraryBLL
{
    public class Class1
    {
    }
}
